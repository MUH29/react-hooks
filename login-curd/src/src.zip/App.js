import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from 'react';

import { BrowserRouter, Route, Link } from 'react-router-dom';


import Dashboard from './components/dashboard/dashboard';

import Login from './components/login/login';
import Signup from './components/signp/signup';

import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import Navbar from './components/navbar/navbar';

import Ad from './components/ad/ad';

import { ads } from './data';

// SPA, single page appliaction
// (sirf 1 html file hoti)
// React, Angular, vue.js, Backbone


// non-SPA, non single page appliaction
// multple html pages

// hooks
// useState
// useRef
// useContext
// useEffect


function Home() {

  return <>
    <Link to="/signup">New User?</Link>
    <Link to="/login">Already a user?</Link>
  </>

}

export function App() {

  let [search, setSearch] = useState('');

  const handleChange = (evt) => {

    setSearch(evt.target.value);

  }

 

  return <div className="App">

    <ToastContainer
      position="top-left"
      autoClose={5000}
      hideProgressBar={false}
      newestOnTop={false}
      closeOnClick
      rtl={false}
      pauseOnFocusLoss
      draggable
      pauseOnHover
    />

    <BrowserRouter>

      <Navbar />

      <input onChange={handleChange} />

      <div className="flex">
        {
          ads.filter((ad) => {

            if (ad.description.toLowerCase().includes(search.toLowerCase())) {
              return true;
            }

          }).map((ad, index) => {
            return <Ad abc={ad} />
          })
        }
      </div>

      {/* <Ad abc={ads[0]} /> */}

      <Route exact path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/signup" component={Signup} />
      <Route path="/dashboard" component={Dashboard} />

    </BrowserRouter>


  </div>

  // return <div className="App">

  //   <BrowserRouter>

  //     <Navbar />

  //     <Route path="/dashboard" component={Dashboard} />
  //     <Route path="/login" component={Login} />

  //     <Route exact path="/" component={Home} />

  //     {/* <Header /> */}

  //     {/* <Dashboard /> */}

  //     {/* <Footer /> */}

  //   </BrowserRouter>

  // </div>

}

