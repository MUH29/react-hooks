import './ad.css'

export default function Ad(props) {

    return <div className="ad">
        <img className="ad-thumb" src={props.abc.img} />
        <h6 className="text-left">{props.abc.price}</h6>
        <p>{
            props.abc.description}</p>
        {/* <button onClick={props.deleteAd}>Delete</button> */}
    </div>;

}