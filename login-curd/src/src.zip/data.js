
export let users = [];

export let ads = [{
    img: "https://apollo-singapore.akamaized.net/v1/files/tq0j5dbx5im43-PK/image;s=200x400;q=60",
    price: 1700000,
    description: "2 kanal plot"
},
{
    img: "https://apollo-singapore.akamaized.net/v1/files/pqslzz2kjih6-PK/image;s=200x400;q=60",
    price: 17000,
    description: "Indian Harmunium"
},
{
    img: "https://apollo-singapore.akamaized.net/v1/files/9zjv4550aijs3-PK/image;s=200x400;q=60",
    price: 400000,
    description: "Tractor"
},
{
    img: "https://apollo-singapore.akamaized.net/v1/files/nholynvkadpf2-PK/image;s=200x400;q=60",
    price: 4000000,
    description: "1 kanal plot"
}
];