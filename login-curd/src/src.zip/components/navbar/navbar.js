import { Link } from 'react-router-dom';

export default function Navbar() {

    return <nav>
        <div class="nav-wrapper">
            <Link to="/" class="brand-logo right">Gamica</Link>

            <ul id="nav-mobile" class="left hide-on-med-and-down">
                <li>
                    <Link to="/login">Login</Link>
                </li>
                <li>
                    <Link to="/dashboard">dashboard</Link>
                </li>
                <li><a href="collapsible.html">JavaScript</a></li>
            </ul>
        </div>
    </nav>

}