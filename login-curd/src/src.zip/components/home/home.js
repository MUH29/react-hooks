export default function Home(){

    return <div>
        <h1>This is out home page, hahha</h1>
    </div>

}