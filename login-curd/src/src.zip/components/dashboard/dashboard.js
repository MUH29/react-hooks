export default function Dashboard() {
    return <h1>This si dashboard</h1>;
}
